package com.cg.agent.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.agent.bean.InsuredBean;
import com.cg.agent.bean.Question;
import com.cg.agent.exception.InsuredException;

public interface IAgentDao {
	
	public String insertInsuredDetails(InsuredBean insuredBean) throws ClassNotFoundException, IOException, SQLException;
//	public PolicyQuestionBean getPolicyQuestions(String BusinessSegment) throws SQLException, ClassNotFoundException, IOException;
	public List<InsuredBean> retriveAll(int agentId) throws InsuredException, ClassNotFoundException, IOException, SQLException;
	public List<Question> getQuestions(String businessSegment) throws SQLException, IOException, ClassNotFoundException;
	public boolean setPremium(int premium) throws SQLException, IOException, ClassNotFoundException;
	
}
